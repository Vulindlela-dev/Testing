﻿namespace VehicleToVehicleCommunication
{
    partial class frmVehicles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVehicles));
            this.pnlVehicle1 = new System.Windows.Forms.Panel();
            this.pnlVehicle2 = new System.Windows.Forms.Panel();
            this.lblVehicleNumber1 = new System.Windows.Forms.Label();
            this.lblVehicle2 = new System.Windows.Forms.Label();
            this.btnBrakeV1 = new System.Windows.Forms.Button();
            this.btnAccV1 = new System.Windows.Forms.Button();
            this.btnAccV2 = new System.Windows.Forms.Button();
            this.btnBrakeV2 = new System.Windows.Forms.Button();
            this.lstVehicle1 = new System.Windows.Forms.ListBox();
            this.lstVehicle2 = new System.Windows.Forms.ListBox();
            this.lblDiverIdV1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDriverID1 = new System.Windows.Forms.TextBox();
            this.txtVehicleID1 = new System.Windows.Forms.TextBox();
            this.txtDriverName1 = new System.Windows.Forms.TextBox();
            this.txtDriverSurname1 = new System.Windows.Forms.TextBox();
            this.txtDriverSurname2 = new System.Windows.Forms.TextBox();
            this.txtDriverName2 = new System.Windows.Forms.TextBox();
            this.txtVehicleID2 = new System.Windows.Forms.TextBox();
            this.txtDriverID2 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.rtbTypeOfIssueV1 = new System.Windows.Forms.RichTextBox();
            this.cmbRoadIDV1 = new System.Windows.Forms.ComboBox();
            this.cmbDirectionV1 = new System.Windows.Forms.ComboBox();
            this.btnAlert = new System.Windows.Forms.Button();
            this.btnAlertV2 = new System.Windows.Forms.Button();
            this.cmbDirectionV2 = new System.Windows.Forms.ComboBox();
            this.cmbRoadIDV2 = new System.Windows.Forms.ComboBox();
            this.rtbTypeOfIssueV2 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnEmergencySystem = new System.Windows.Forms.Button();
            this.btnStateV1 = new System.Windows.Forms.Button();
            this.btnStateV2 = new System.Windows.Forms.Button();
            this.pnlVehicle1.SuspendLayout();
            this.pnlVehicle2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlVehicle1
            // 
            this.pnlVehicle1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVehicle1.BackgroundImage")));
            this.pnlVehicle1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlVehicle1.Controls.Add(this.btnStateV1);
            this.pnlVehicle1.Controls.Add(this.panel1);
            this.pnlVehicle1.Controls.Add(this.txtDriverSurname1);
            this.pnlVehicle1.Controls.Add(this.txtDriverName1);
            this.pnlVehicle1.Controls.Add(this.txtVehicleID1);
            this.pnlVehicle1.Controls.Add(this.txtDriverID1);
            this.pnlVehicle1.Controls.Add(this.label3);
            this.pnlVehicle1.Controls.Add(this.label2);
            this.pnlVehicle1.Controls.Add(this.label1);
            this.pnlVehicle1.Controls.Add(this.lblDiverIdV1);
            this.pnlVehicle1.Controls.Add(this.lstVehicle1);
            this.pnlVehicle1.Controls.Add(this.btnAccV1);
            this.pnlVehicle1.Controls.Add(this.btnBrakeV1);
            this.pnlVehicle1.Controls.Add(this.lblVehicleNumber1);
            this.pnlVehicle1.Location = new System.Drawing.Point(12, 12);
            this.pnlVehicle1.Name = "pnlVehicle1";
            this.pnlVehicle1.Size = new System.Drawing.Size(584, 467);
            this.pnlVehicle1.TabIndex = 0;
            // 
            // pnlVehicle2
            // 
            this.pnlVehicle2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVehicle2.BackgroundImage")));
            this.pnlVehicle2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlVehicle2.Controls.Add(this.btnStateV2);
            this.pnlVehicle2.Controls.Add(this.panel2);
            this.pnlVehicle2.Controls.Add(this.txtDriverSurname2);
            this.pnlVehicle2.Controls.Add(this.label4);
            this.pnlVehicle2.Controls.Add(this.txtDriverName2);
            this.pnlVehicle2.Controls.Add(this.lstVehicle2);
            this.pnlVehicle2.Controls.Add(this.txtVehicleID2);
            this.pnlVehicle2.Controls.Add(this.txtDriverID2);
            this.pnlVehicle2.Controls.Add(this.label5);
            this.pnlVehicle2.Controls.Add(this.btnAccV2);
            this.pnlVehicle2.Controls.Add(this.label6);
            this.pnlVehicle2.Controls.Add(this.label7);
            this.pnlVehicle2.Controls.Add(this.lblVehicle2);
            this.pnlVehicle2.Controls.Add(this.btnBrakeV2);
            this.pnlVehicle2.Location = new System.Drawing.Point(698, 12);
            this.pnlVehicle2.Name = "pnlVehicle2";
            this.pnlVehicle2.Size = new System.Drawing.Size(586, 467);
            this.pnlVehicle2.TabIndex = 1;
            // 
            // lblVehicleNumber1
            // 
            this.lblVehicleNumber1.AutoSize = true;
            this.lblVehicleNumber1.BackColor = System.Drawing.Color.Transparent;
            this.lblVehicleNumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehicleNumber1.ForeColor = System.Drawing.Color.White;
            this.lblVehicleNumber1.Location = new System.Drawing.Point(220, 29);
            this.lblVehicleNumber1.Name = "lblVehicleNumber1";
            this.lblVehicleNumber1.Size = new System.Drawing.Size(141, 29);
            this.lblVehicleNumber1.TabIndex = 0;
            this.lblVehicleNumber1.Text = "VEHICLE 1";
            // 
            // lblVehicle2
            // 
            this.lblVehicle2.AutoSize = true;
            this.lblVehicle2.BackColor = System.Drawing.Color.Transparent;
            this.lblVehicle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehicle2.ForeColor = System.Drawing.Color.White;
            this.lblVehicle2.Location = new System.Drawing.Point(274, 29);
            this.lblVehicle2.Name = "lblVehicle2";
            this.lblVehicle2.Size = new System.Drawing.Size(141, 29);
            this.lblVehicle2.TabIndex = 1;
            this.lblVehicle2.Text = "VEHICLE 2";
            // 
            // btnBrakeV1
            // 
            this.btnBrakeV1.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnBrakeV1.Location = new System.Drawing.Point(19, 338);
            this.btnBrakeV1.Name = "btnBrakeV1";
            this.btnBrakeV1.Size = new System.Drawing.Size(108, 108);
            this.btnBrakeV1.TabIndex = 1;
            this.btnBrakeV1.Text = "BRAKE";
            this.btnBrakeV1.UseVisualStyleBackColor = false;
            // 
            // btnAccV1
            // 
            this.btnAccV1.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAccV1.Location = new System.Drawing.Point(133, 338);
            this.btnAccV1.Name = "btnAccV1";
            this.btnAccV1.Size = new System.Drawing.Size(108, 108);
            this.btnAccV1.TabIndex = 2;
            this.btnAccV1.Text = "ACCELERATE";
            this.btnAccV1.UseVisualStyleBackColor = false;
            // 
            // btnAccV2
            // 
            this.btnAccV2.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAccV2.Location = new System.Drawing.Point(130, 338);
            this.btnAccV2.Name = "btnAccV2";
            this.btnAccV2.Size = new System.Drawing.Size(108, 108);
            this.btnAccV2.TabIndex = 4;
            this.btnAccV2.Text = "ACCELERATE";
            this.btnAccV2.UseVisualStyleBackColor = false;
            // 
            // btnBrakeV2
            // 
            this.btnBrakeV2.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnBrakeV2.Location = new System.Drawing.Point(16, 338);
            this.btnBrakeV2.Name = "btnBrakeV2";
            this.btnBrakeV2.Size = new System.Drawing.Size(108, 108);
            this.btnBrakeV2.TabIndex = 3;
            this.btnBrakeV2.Text = "BRAKE";
            this.btnBrakeV2.UseVisualStyleBackColor = false;
            // 
            // lstVehicle1
            // 
            this.lstVehicle1.BackColor = System.Drawing.Color.RoyalBlue;
            this.lstVehicle1.FormattingEnabled = true;
            this.lstVehicle1.Location = new System.Drawing.Point(247, 338);
            this.lstVehicle1.Name = "lstVehicle1";
            this.lstVehicle1.Size = new System.Drawing.Size(316, 108);
            this.lstVehicle1.TabIndex = 3;
            // 
            // lstVehicle2
            // 
            this.lstVehicle2.BackColor = System.Drawing.Color.RoyalBlue;
            this.lstVehicle2.FormattingEnabled = true;
            this.lstVehicle2.Location = new System.Drawing.Point(253, 338);
            this.lstVehicle2.Name = "lstVehicle2";
            this.lstVehicle2.Size = new System.Drawing.Size(316, 108);
            this.lstVehicle2.TabIndex = 4;
            // 
            // lblDiverIdV1
            // 
            this.lblDiverIdV1.AutoSize = true;
            this.lblDiverIdV1.BackColor = System.Drawing.Color.Transparent;
            this.lblDiverIdV1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDiverIdV1.Location = new System.Drawing.Point(19, 78);
            this.lblDiverIdV1.Name = "lblDiverIdV1";
            this.lblDiverIdV1.Size = new System.Drawing.Size(62, 13);
            this.lblDiverIdV1.TabIndex = 4;
            this.lblDiverIdV1.Text = "DRIVER ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(19, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "VEHICLE ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(19, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "DRIVER NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(19, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "DRIVER SURNAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(13, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "DRIVER SURNAME";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(13, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "DRIVER NAME";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(13, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "VEHICLE ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(13, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "DRIVER ID";
            // 
            // txtDriverID1
            // 
            this.txtDriverID1.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtDriverID1.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDriverID1.Location = new System.Drawing.Point(158, 70);
            this.txtDriverID1.Name = "txtDriverID1";
            this.txtDriverID1.Size = new System.Drawing.Size(186, 20);
            this.txtDriverID1.TabIndex = 8;
            // 
            // txtVehicleID1
            // 
            this.txtVehicleID1.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtVehicleID1.ForeColor = System.Drawing.SystemColors.Info;
            this.txtVehicleID1.Location = new System.Drawing.Point(158, 93);
            this.txtVehicleID1.Name = "txtVehicleID1";
            this.txtVehicleID1.Size = new System.Drawing.Size(186, 20);
            this.txtVehicleID1.TabIndex = 9;
            // 
            // txtDriverName1
            // 
            this.txtDriverName1.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtDriverName1.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDriverName1.Location = new System.Drawing.Point(158, 115);
            this.txtDriverName1.Name = "txtDriverName1";
            this.txtDriverName1.Size = new System.Drawing.Size(186, 20);
            this.txtDriverName1.TabIndex = 10;
            // 
            // txtDriverSurname1
            // 
            this.txtDriverSurname1.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtDriverSurname1.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDriverSurname1.Location = new System.Drawing.Point(158, 137);
            this.txtDriverSurname1.Name = "txtDriverSurname1";
            this.txtDriverSurname1.Size = new System.Drawing.Size(186, 20);
            this.txtDriverSurname1.TabIndex = 11;
            // 
            // txtDriverSurname2
            // 
            this.txtDriverSurname2.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtDriverSurname2.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDriverSurname2.Location = new System.Drawing.Point(130, 137);
            this.txtDriverSurname2.Name = "txtDriverSurname2";
            this.txtDriverSurname2.Size = new System.Drawing.Size(186, 20);
            this.txtDriverSurname2.TabIndex = 15;
            // 
            // txtDriverName2
            // 
            this.txtDriverName2.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtDriverName2.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDriverName2.Location = new System.Drawing.Point(130, 115);
            this.txtDriverName2.Name = "txtDriverName2";
            this.txtDriverName2.Size = new System.Drawing.Size(186, 20);
            this.txtDriverName2.TabIndex = 14;
            // 
            // txtVehicleID2
            // 
            this.txtVehicleID2.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtVehicleID2.ForeColor = System.Drawing.SystemColors.Info;
            this.txtVehicleID2.Location = new System.Drawing.Point(130, 93);
            this.txtVehicleID2.Name = "txtVehicleID2";
            this.txtVehicleID2.Size = new System.Drawing.Size(186, 20);
            this.txtVehicleID2.TabIndex = 13;
            // 
            // txtDriverID2
            // 
            this.txtDriverID2.BackColor = System.Drawing.Color.RoyalBlue;
            this.txtDriverID2.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDriverID2.Location = new System.Drawing.Point(130, 70);
            this.txtDriverID2.Name = "txtDriverID2";
            this.txtDriverID2.Size = new System.Drawing.Size(186, 20);
            this.txtDriverID2.TabIndex = 12;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btnAlert);
            this.panel1.Controls.Add(this.cmbDirectionV1);
            this.panel1.Controls.Add(this.cmbRoadIDV1);
            this.panel1.Controls.Add(this.rtbTypeOfIssueV1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.ForeColor = System.Drawing.SystemColors.Info;
            this.panel1.Location = new System.Drawing.Point(22, 173);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(541, 149);
            this.panel1.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.btnAlertV2);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.cmbDirectionV2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.cmbRoadIDV2);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.rtbTypeOfIssueV2);
            this.panel2.ForeColor = System.Drawing.SystemColors.Info;
            this.panel2.Location = new System.Drawing.Point(16, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(541, 149);
            this.panel2.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "TYPE OF ISSUE";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(273, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "ROAD ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(273, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "DIRECTION";
            // 
            // rtbTypeOfIssueV1
            // 
            this.rtbTypeOfIssueV1.BackColor = System.Drawing.Color.RoyalBlue;
            this.rtbTypeOfIssueV1.Location = new System.Drawing.Point(113, 19);
            this.rtbTypeOfIssueV1.Name = "rtbTypeOfIssueV1";
            this.rtbTypeOfIssueV1.Size = new System.Drawing.Size(154, 127);
            this.rtbTypeOfIssueV1.TabIndex = 3;
            this.rtbTypeOfIssueV1.Text = "";
            // 
            // cmbRoadIDV1
            // 
            this.cmbRoadIDV1.BackColor = System.Drawing.Color.RoyalBlue;
            this.cmbRoadIDV1.FormattingEnabled = true;
            this.cmbRoadIDV1.Location = new System.Drawing.Point(351, 10);
            this.cmbRoadIDV1.Name = "cmbRoadIDV1";
            this.cmbRoadIDV1.Size = new System.Drawing.Size(169, 21);
            this.cmbRoadIDV1.TabIndex = 4;
            // 
            // cmbDirectionV1
            // 
            this.cmbDirectionV1.BackColor = System.Drawing.Color.RoyalBlue;
            this.cmbDirectionV1.FormattingEnabled = true;
            this.cmbDirectionV1.Items.AddRange(new object[] {
            "South",
            "West",
            "East",
            "North"});
            this.cmbDirectionV1.Location = new System.Drawing.Point(351, 42);
            this.cmbDirectionV1.Name = "cmbDirectionV1";
            this.cmbDirectionV1.Size = new System.Drawing.Size(169, 21);
            this.cmbDirectionV1.TabIndex = 5;
            // 
            // btnAlert
            // 
            this.btnAlert.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAlert.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAlert.Location = new System.Drawing.Point(276, 81);
            this.btnAlert.Name = "btnAlert";
            this.btnAlert.Size = new System.Drawing.Size(244, 46);
            this.btnAlert.TabIndex = 6;
            this.btnAlert.Text = "ALERT";
            this.btnAlert.UseVisualStyleBackColor = false;
            // 
            // btnAlertV2
            // 
            this.btnAlertV2.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAlertV2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAlertV2.Location = new System.Drawing.Point(272, 81);
            this.btnAlertV2.Name = "btnAlertV2";
            this.btnAlertV2.Size = new System.Drawing.Size(244, 46);
            this.btnAlertV2.TabIndex = 13;
            this.btnAlertV2.Text = "ALERT";
            this.btnAlertV2.UseVisualStyleBackColor = false;
            // 
            // cmbDirectionV2
            // 
            this.cmbDirectionV2.BackColor = System.Drawing.Color.RoyalBlue;
            this.cmbDirectionV2.FormattingEnabled = true;
            this.cmbDirectionV2.Items.AddRange(new object[] {
            "South",
            "West",
            "East",
            "North"});
            this.cmbDirectionV2.Location = new System.Drawing.Point(347, 42);
            this.cmbDirectionV2.Name = "cmbDirectionV2";
            this.cmbDirectionV2.Size = new System.Drawing.Size(169, 21);
            this.cmbDirectionV2.TabIndex = 12;
            // 
            // cmbRoadIDV2
            // 
            this.cmbRoadIDV2.BackColor = System.Drawing.Color.RoyalBlue;
            this.cmbRoadIDV2.FormattingEnabled = true;
            this.cmbRoadIDV2.Location = new System.Drawing.Point(347, 10);
            this.cmbRoadIDV2.Name = "cmbRoadIDV2";
            this.cmbRoadIDV2.Size = new System.Drawing.Size(169, 21);
            this.cmbRoadIDV2.TabIndex = 11;
            // 
            // rtbTypeOfIssueV2
            // 
            this.rtbTypeOfIssueV2.BackColor = System.Drawing.Color.RoyalBlue;
            this.rtbTypeOfIssueV2.Location = new System.Drawing.Point(109, 19);
            this.rtbTypeOfIssueV2.Name = "rtbTypeOfIssueV2";
            this.rtbTypeOfIssueV2.Size = new System.Drawing.Size(154, 127);
            this.rtbTypeOfIssueV2.TabIndex = 10;
            this.rtbTypeOfIssueV2.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(269, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "DIRECTION";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(269, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "ROAD ID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "TYPE OF ISSUE";
            // 
            // btnEmergencySystem
            // 
            this.btnEmergencySystem.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnEmergencySystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmergencySystem.Location = new System.Drawing.Point(602, 12);
            this.btnEmergencySystem.Name = "btnEmergencySystem";
            this.btnEmergencySystem.Size = new System.Drawing.Size(90, 467);
            this.btnEmergencySystem.TabIndex = 2;
            this.btnEmergencySystem.Text = "Emergency Vehicle Approach";
            this.btnEmergencySystem.UseVisualStyleBackColor = false;
            // 
            // btnStateV1
            // 
            this.btnStateV1.BackColor = System.Drawing.Color.Red;
            this.btnStateV1.Location = new System.Drawing.Point(417, 70);
            this.btnStateV1.Name = "btnStateV1";
            this.btnStateV1.Size = new System.Drawing.Size(125, 87);
            this.btnStateV1.TabIndex = 13;
            this.btnStateV1.Text = "OFF";
            this.btnStateV1.UseVisualStyleBackColor = false;
            // 
            // btnStateV2
            // 
            this.btnStateV2.BackColor = System.Drawing.Color.Red;
            this.btnStateV2.Location = new System.Drawing.Point(396, 70);
            this.btnStateV2.Name = "btnStateV2";
            this.btnStateV2.Size = new System.Drawing.Size(125, 87);
            this.btnStateV2.TabIndex = 14;
            this.btnStateV2.Text = "OFF";
            this.btnStateV2.UseVisualStyleBackColor = false;
            // 
            // frmVehicles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1285, 491);
            this.Controls.Add(this.btnEmergencySystem);
            this.Controls.Add(this.pnlVehicle2);
            this.Controls.Add(this.pnlVehicle1);
            this.Name = "frmVehicles";
            this.Text = "Form1";
            this.pnlVehicle1.ResumeLayout(false);
            this.pnlVehicle1.PerformLayout();
            this.pnlVehicle2.ResumeLayout(false);
            this.pnlVehicle2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlVehicle1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAlertV2;
        private System.Windows.Forms.ComboBox cmbDirectionV2;
        private System.Windows.Forms.ComboBox cmbRoadIDV2;
        private System.Windows.Forms.RichTextBox rtbTypeOfIssueV2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnAlert;
        private System.Windows.Forms.ComboBox cmbDirectionV1;
        private System.Windows.Forms.ComboBox cmbRoadIDV1;
        private System.Windows.Forms.RichTextBox rtbTypeOfIssueV1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDriverSurname1;
        private System.Windows.Forms.TextBox txtDriverName1;
        private System.Windows.Forms.TextBox txtVehicleID1;
        private System.Windows.Forms.TextBox txtDriverID1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDiverIdV1;
        private System.Windows.Forms.ListBox lstVehicle1;
        private System.Windows.Forms.Button btnAccV1;
        private System.Windows.Forms.Button btnBrakeV1;
        private System.Windows.Forms.Label lblVehicleNumber1;
        private System.Windows.Forms.Panel pnlVehicle2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtDriverSurname2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDriverName2;
        private System.Windows.Forms.ListBox lstVehicle2;
        private System.Windows.Forms.TextBox txtVehicleID2;
        private System.Windows.Forms.TextBox txtDriverID2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAccV2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblVehicle2;
        private System.Windows.Forms.Button btnBrakeV2;
        private System.Windows.Forms.Button btnStateV1;
        private System.Windows.Forms.Button btnStateV2;
        private System.Windows.Forms.Button btnEmergencySystem;
    }
}

