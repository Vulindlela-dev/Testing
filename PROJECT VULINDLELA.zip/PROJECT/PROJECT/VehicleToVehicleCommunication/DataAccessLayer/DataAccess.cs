﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Collections;

namespace DataAccessLayer
{
   public class DataAccess
    {
        SqlConnectionStringBuilder connection = new SqlConnectionStringBuilder();
        public DataAccess()
        {
            connection.DataSource = @"DESKTOP-HJE5GH9\SQLEXPRESS01";
            connection.InitialCatalog = "Vulindlela";
            connection.IntegratedSecurity = true;
        }

        public DataSet ReadData(string tableName)
        {
            DataSet data = new DataSet();

            using (SqlConnection connect = new SqlConnection(connection.ToString()))
            {
                string query = string.Format(@"Select * From {0}", tableName);
                connect.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connect);
                dataAdapter.FillSchema(data, SchemaType.Source, tableName);
                dataAdapter.Fill(data, tableName);
            }
            return data;
        }
    }
}
