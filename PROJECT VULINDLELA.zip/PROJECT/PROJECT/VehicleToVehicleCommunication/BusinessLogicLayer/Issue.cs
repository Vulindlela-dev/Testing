﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;

namespace BusinessLogicLayer
{
  public class Issue : IVulindlena
    {
        int issueNum;

        public int IssueNum
        {
            get { return issueNum; }
            set { issueNum = value; }
        }
        int driverId;

        public int DriverId
        {
            get { return driverId; }
            set { driverId = value; }
        }
        int vehicleId;

        public int VehicleId
        {
            get { return vehicleId; }
            set { vehicleId = value; }
        }
        string typeOfIssue;

        public string TypeOfIssue
        {
            get { return typeOfIssue; }
            set { typeOfIssue = value; }
        }
        string location;

        public string Location
        {
            get { return location; }
            set { location = value; }
        }
        DateTime time;

        public DateTime Time
        {
            get { return time; }
            set { time = value; }
        }
        string issueLevel;

        public string IssueLevel
        {
            get { return issueLevel; }
            set { issueLevel = value; }
        }
        string decription;

        public string Decription
        {
            get { return decription; }
            set { decription = value; }
        }

        public Issue()
        {

        }
        public Issue(int issueNum,int driverId, int vehicleId, string typeOfIssue, string location,DateTime time, string issueLevel,string description)
        {
            this.IssueNum = issueNum;
            this.DriverId = driverId;
            this.VehicleId = vehicleId;
            this.TypeOfIssue = typeOfIssue;
            this.Location = location;
            this.Time = time;
            this.IssueLevel = issueLevel;
            this.Decription = description;

        }


        public void getData()
        {
            throw new NotImplementedException();
        }

        public void insertData()
        {
            throw new NotImplementedException();
        }

        public void updateData()
        {
            throw new NotImplementedException();
        }

        public void deleteData()
        {
            throw new NotImplementedException();
        }
    }
}
