﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;

namespace BusinessLogicLayer
{
  public class Vehicle : IVulindlena
    {
        int vinNum;

        public int VinNum
        {
            get { return vinNum; }
            set { vinNum = value; }
        }
        int driverId;

        public int DriverId
        {
            get { return driverId; }
            set { driverId = value; }
        }
        string manufacture;

        public string Manufacture
        {
            get { return manufacture; }
            set { manufacture = value; }
        }
        string model;

        public string Model
        {
            get { return model; }
            set { model = value; }
        }
        string year;

        public string Year
        {
            get { return year; }
            set { year = value; }
        }
        string vehicleType;

        public string VehicleType
        {
            get { return vehicleType; }
            set { vehicleType = value; }
        }
        string color;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }
        string otherDescription;

        public string OtherDescription
        {
            get { return otherDescription; }
            set { otherDescription = value; }
        }
        public Vehicle()
        {

        }
        public Vehicle(int vinNum, int driverId, string manufacture, string model, string year, string type, string color,string otherDescr)
        {
            this.VinNum = vinNum;
            this.DriverId = driverId;
            this.Manufacture = manufacture;
            this.Model = model;
            this.Year = year;
            this.VehicleType = type;
            this.Color = color;
            this.OtherDescription = otherDescr;
        }

        public void getData()
        {
            throw new NotImplementedException();
        }

        public void insertData()
        {
            throw new NotImplementedException();
        }

        public void updateData()
        {
            throw new NotImplementedException();
        }

        public void deleteData()
        {
            throw new NotImplementedException();
        }
    }
}
