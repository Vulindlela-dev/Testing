﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;


namespace BusinessLogicLayer
{
   public class Driver: IVulindlena
    {
        int driverId;

        public int DriverId
        {
            get { return driverId; }
            set { driverId = value; }
        }
        string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        string surname;

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        string licenseNum;

        public string LicenseNum
        {
            get { return licenseNum; }
            set { licenseNum = value; }
        }
        string cellNum;

        public string CellNum
        {
            get { return cellNum; }
            set { cellNum = value; }
        }
        string address;

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public Driver()
        {

        }
        public Driver(int driverId, string name, string surname,string id, string licenseNum, string cellNum, string address,string email)
        {
            this.DriverId = driverId;
            this.Name = name;
            this.Surname = surname;
            this.Id = id;
            this.LicenseNum = licenseNum;
            this.CellNum = cellNum;
            this.Address = address;
            this.Email = email;
        }


        public void getData()
        {
            throw new NotImplementedException();
        }

        public void insertData()
        {
            throw new NotImplementedException();
        }

        public void updateData()
        {
            throw new NotImplementedException();
        }

        public void deleteData()
        {
            throw new NotImplementedException();
        }
    }
}
